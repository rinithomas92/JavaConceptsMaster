public class Testtrycatch1{
  public static void main(String args[]){
      int data=50/0;
  
      System.out.println("rest of the code..."); //THIS WONT RUN
}
}
