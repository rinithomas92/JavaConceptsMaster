package java_design_patterns.gof_behavioral.strategy;

public interface MoneyTransferStrategy {
    void transfer(int amount);
}
