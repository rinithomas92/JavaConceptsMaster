package java_design_patterns.gof_structural.proxy;

public interface Image {
    void display();
}
