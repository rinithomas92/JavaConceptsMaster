package java_design_patterns.gof_creational.factory2;

public class Square implements Shape {

    @Override
    public void draw() {
        System.out.println("SQUARE IS DRAWN");
    }
}
