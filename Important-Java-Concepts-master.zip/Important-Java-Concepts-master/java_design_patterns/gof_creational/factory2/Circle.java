package java_design_patterns.gof_creational.factory2;

public class Circle implements Shape {

    @Override
    public void draw() {
            System.out.println("CIRCLE IS DRAWN");
    }
}
