package java_design_patterns.gof_creational.factory2;

public interface Shape {
    public void draw();
}
