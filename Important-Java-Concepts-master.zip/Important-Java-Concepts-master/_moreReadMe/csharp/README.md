# C# for Java Developers

![1](https://user-images.githubusercontent.com/2780145/35191311-1f029676-fe9e-11e7-961a-3c7d2e64afa5.png)

![2](https://user-images.githubusercontent.com/2780145/35191312-1f29ac8e-fe9e-11e7-9670-7bbd1e45ab38.png)

![3](https://user-images.githubusercontent.com/2780145/35191313-1f52db22-fe9e-11e7-89c3-de5a3ad319c2.png)

![4](https://user-images.githubusercontent.com/2780145/35191314-1f7d7fda-fe9e-11e7-8bb1-bbbc08b5eb5d.png)

![5](https://user-images.githubusercontent.com/2780145/35191315-1fc857f8-fe9e-11e7-85cc-084c5a0f5a7c.png)

![6](https://user-images.githubusercontent.com/2780145/35191322-5dd49ebc-fe9e-11e7-9a0a-a369e16739ea.png)

![7](https://user-images.githubusercontent.com/2780145/35191495-df19d232-fea1-11e7-8ec9-f61351121c98.png)

![8](https://user-images.githubusercontent.com/2780145/35191496-df434aae-fea1-11e7-8a7e-c02543c64b6f.png)

![9](https://user-images.githubusercontent.com/2780145/35191498-e0fdb302-fea1-11e7-82c2-f27ee0ab45dd.png)

![10](https://user-images.githubusercontent.com/2780145/35191323-5dfc6a3c-fe9e-11e7-90a4-a94db4f9e2fa.png)

![11](https://user-images.githubusercontent.com/2780145/35191324-5e23ac1e-fe9e-11e7-847f-ab3fa82dd9f7.png)

![12](https://user-images.githubusercontent.com/2780145/35191325-5e4cb866-fe9e-11e7-9d6f-7c34eb58b495.png)

For More Detailed Comparison - https://en.wikipedia.org/wiki/Comparison_of_C_Sharp_and_Java
