
/** 
This  
is  
documentation  
comment 
*/  
public class CommentExample2 {  
public static void main(String[] args) {  
/* 
This  
is  
multi line  
comment 
*/  
    System.out.println("Hello java comments!");  //This is single line comment  
}  
}  