// There are two ways to achieve abstraction in java
// Abstract class (0 to 100%) and Interface (100%)

interface printable{  
void print();  
}  
class A6 implements printable{  
public void print(){System.out.println("Hello");}  
  
public static void main(String args[]){  
A6 obj = new A6();  
obj.print();  
 }  
}  