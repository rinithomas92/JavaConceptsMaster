// A java package is a group of similar types of 
// classes, interfaces and sub-packages.

//save as C.java otherwise Compilte Time Error  
  
class A{}  
class B{}  
public class C{}  